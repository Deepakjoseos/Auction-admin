import React from "react";
import RegionForm from "../regionForm";

const AddRegion = () => {
  return <RegionForm mode="ADD" />;
};

export default AddRegion;
